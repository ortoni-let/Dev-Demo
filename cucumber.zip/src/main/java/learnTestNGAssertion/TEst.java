package learnTestNGAssertion;

import java.util.Arrays;

public class TEst {
	
	public static void main(String[] args) {
		String a = "A";
		String b = "C";
		System.out.println(b.compareTo(a));
	}

}
