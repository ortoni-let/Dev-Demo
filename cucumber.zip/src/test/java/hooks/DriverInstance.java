package hooks;

import org.openqa.selenium.chrome.ChromeDriver;

public class DriverInstance {
	protected static ChromeDriver driver;

}
